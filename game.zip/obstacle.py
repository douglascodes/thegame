import pygame, sys, os, display
from pygame.locals import *

class Obstacle(pygame.sprite.Sprite()):
    pass

class AirObs (Obstacle):
    pass

class LandObs (Obstacle):
    pass
